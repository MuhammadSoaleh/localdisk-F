<?php
$localhost = 'localhost';
$un ='root';
$password ="";
$db ="miocacontact"
;
$conn =mysqli_connect($localhost,$un,$password,$db);
?>