<?php
$localhost = 'localhost';
$un ='root';
$password ="";
$db ="newdb";
$conn =mysqli_connect($localhost,$un,$password,$db);
?>